%  Matlab code that accompanies the paper
%  "Seasonal snow cover decreases fraction of young
%  water in high Alpine catchments"
%  submitted to Hydrological Processes Written by
%  Natalie Ceperley, University of Bern, natalie.ceperley@giub.unibe.ch
%  25-Mar-2020, Matlab version: '9.5.0.1298439 (R2018b) Update 7'

% Main code to run all subfunctions.
% The code can be run for the three case studies presented in the paper.

% Readme.txt explains data preparation; required data:
%
% - catchment DEM
%
% - isotopes of snow, rain, streamflow (either O18 or DH) with
%   corresponding sample times, elevations and with indications on:
%       for snow: indications about depth of sampled layer, indicated in
%           terms of layer bottom (depth in cm) and layer top (depth in cm);
%           the layer depth is the difference
%
%       for streamflow: corresponding instantaneous discharge in m3/s
%
%       for rainfall: sample volume in mm
%
% - meteo data: containing air temperature in �C and precipitaion in mm
%   per hourly time step; the meteo data should extend beyond the
%   isotope sampling period
%
% - meteo/snow parameter file (casestudyparameters.cvs)
%   containing meteo station elevation, air temperature lapse rate,
%   critical air temperature for rain/snow separation

% All Data should be stored in a folder "../Data/case study name"



clear all
close all
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% PART 1: prepare data, parameters, run snow pack model
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 1.1. Define workspace and select a site


wdGlobal = pwd;
%wdGlobal='E:\Articles\InRevision\HP_WaterAge_VdN\Revision\MatlabCodePublish_v2.3';
cd(wdGlobal)
addpath(genpath(cd))% add all paths for reading
sitenameAll={'vdn', 'nbpv', 'bcc'};
selSite=input('Select a site, VdN: 1, NBPV: 2, BCC: 3 ' );
sitename = sitenameAll{selSite};

if exist(['ComputedOutput','/', sitename], 'dir')==0 % make subfolder for results
    mkdir(['ComputedOutput','/', sitename])
end
cd(['ComputedOutput','/', sitename])
generalresultspath=cd;

%% 1.2 Define computational parameters
initialimport = 0;  % set to 1 for the first time run, otherwise put as 0

nTimeStepsPerYear=365; %
minQdataPerYear = 12; % this is the minimum number of data points of isotopes in stream water required per year for convolution
% years with less observations are not retained, see
% datapreparation_convolution
nMC=10000; % number of Monte Carlo samples for ratio uncertainty estimation

nprecipIsoConv=1; % number of precipIsotope realisations to use as input to convolution method;
% if 1: use 1 random realisation of sine fitting to
% precipitation isotopes (obtained in Part 2 below),
% if n: use n random realisations of sine fitting
% using n samples in the MCMC approach results in a
% high number of simulations and does not increase the
% posterior variability;
nMCMCSamples=500; % number of samples to draw from the posterior distribution of the convolution parameters

%% 1.3 Define parameters for sine curve fitting isotope time series parameters

flowweighted = 1;               % set to 1 to flow weight sine fit of streamflow data, to anything else to fit without weights.

sinefitopts = fitoptions( 'Method', 'NonlinearLeastSquares' ); % define the default options used here; attention, this is a global variable in Matlab
% i.e. it changes value within functions and brings the changed value back
% to the main programme
sinefitopts.Display = 'Off';
sinefitopts.Robust = 'Bisquare'; % comment this line for no robust
alphaFitFun=0.95; % default value for confidence intervals during fitting

preciptimeserieschoice = 0;

% preciptimeserieschoice:
%   set to -1 to choose interactively,
%   set to 0 to explore all options
%   set to a six digit number to compute a
%   given option, ranging from 111111 to 425746
%   (see Table 1 of the paper or below)
%   to see all possible options go to
%   constructisotimeseries.m or type
%   constructisotimeseries(-1);


%% 1.3 Define snow pack model parameters
data=importdata(['casestudyparameters_',sitename,'.csv']);snowparam=data.data;

meteoStationElev = snowparam(1); % elevation, m asl., of precip and temp time series meteo station
lapserate= snowparam(2);% constant air temp. lapse rate, �C/100m, has to be negative
degDayFact=snowparam(3);% degree day melt factor, mm/degC/day
snowfallThreshMin=snowparam(4); % �C, below this threshold, all precip as snowfall
snowfallThreshMax=snowparam(5); % �C, above this threshold, all precip as rain
if snowfallThreshMax<snowfallThreshMin|degDayFact<0|lapserate>0|meteoStationElev<0
    error('Check snow pack parameters')
end
tmelt = 0;  %: critical temp. for melt, default value is 0,
swe0  = 0; %: initial snow water equivalent (in mm) - 0 if start before snow season
numbElevationBands=100; %  number of elevation bands for meteo interpolation and snowpack computation

%% 1.4 Initial Import Data files
% read meteo.csv, DEM.csv, snowisotopes.csv,
% rainisotopes.csv, and streamisotopes.csv and save as mat files
if initialimport ==1
    [precip,temp,datemeteo,...
        iso_rain_dt0,iso_rain_dtc ,iso_rain_elev ,iso_rain ,iso_rain_mm,...
        iso_snow_dt,iso_snow_elev,iso_snow,iso_snow_bot_layer_cm,iso_snow_top_layer_cm,...
        iso_q_dt,iso_q,iso_q_m3s,iso_q_MeteoTime,demPixels]=importcasestudydata(sitename);
else
    load(['meteo_',sitename,'.mat'],'precip','temp','datemeteo');
    load(['rainisotopes_',sitename,'.mat'], 'iso_rain_dt0', 'iso_rain_dtc', 'iso_rain_elev', 'iso_rain', 'iso_rain_mm')
    load(['snowisotopes_',sitename,'.mat'],  'iso_snow_dt','iso_snow_elev','iso_snow','iso_snow_bot_layer_cm','iso_snow_top_layer_cm')
    load(['streamisotopes_',sitename,'.mat'], 'iso_q_dt','iso_q','iso_q_m3s','iso_q_MeteoTime')
    load(['elevation_',sitename,'.mat'],'demPixels')
    
end

if max(datemeteo(2:end)-datemeteo(1:end-1))>1
    error('The meteo data does not have continuous daily data')
end

% set time series parameters
nyears=length(precip)/nTimeStepsPerYear;
nTimeSteps=length(precip);
[startyear,dummy,dummy] = datevec(min(datemeteo));
initialtime=datenum(startyear-1, 12, 31);
t=datemeteo-initialtime; % daily meteo time steps starting at year zero, reference time, should be continuous
clear startyear

%% 1.5 Run the Snow Pack Model - to obtain equivalent precipitation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% without isotopes


% interpolate temperature
[tempMatrix,areaRatio,limsElevationBands]=tempInterpol(temp,meteoStationElev,lapserate,demPixels,numbElevationBands);

% snow pack per elevation band, swe:
[swe,snowmelt,rainfall,snowfall]=swesim(precip,tempMatrix,swe0,degDayFact,tmelt,snowfallThreshMin, snowfallThreshMax);
peq = snowmelt + rainfall;
peqtot= (areaRatio(:)'*peq')'; %new on 15 June
rainonsnow = sum(and(rainfall>0, swe>0))./sum(rainfall>0)*areaRatio(:);


%% 1.6 Prepare streamflow isotope data and corresponding sine curve
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tiq = iso_q_dt-initialtime; % time vector for streamflow q

% sort the data
[xDataQ, ind ] = sort(tiq);yDataQ = iso_q(ind);wDataQ = iso_q_m3s;
% remove missing values
bad = isnan(xDataQ+yDataQ+wDataQ);xDataQ(bad)=[];yDataQ(bad)=[];wDataQ(bad) = [];
% fitting sine wave to iso data
[xDataQ, yDataQ, wDataQ] = prepareCurveData(xDataQ, yDataQ, wDataQ);
if flowweighted ==1
    weightsQ=wDataQ;
else
    weightsQ=[];
end

sinefitopts.StartPoint = [5 90 0];
[ampliQIso,phaseQiso,meanQiso,confIntQIso,adjR2Qiso,dfeQIso]=sinefit(xDataQ,yDataQ,weightsQ,nTimeStepsPerYear,sinefitopts);
%amplitude  phase  mean value confid interval, coeff of det, degree of freedom

% look at result:
% streamIso= ampliQIso.*sin(2.*pi./nTimeStepsPerYear.*(t-phaseQiso))+meanQiso;
% plot(xData1,yData1,'o');hold on; plot(t,streamIso,'-r')


% uncertainty estimates of sine fitting
[stdQamplitude,stdQmeanval,stdQphase]=fituncertainty(confIntQIso,dfeQIso,alphaFitFun);

save(['streamflow_ampli_',sitename],'ampliQIso','phaseQiso','meanQiso','confIntQIso','adjR2Qiso','dfeQIso','stdQamplitude','stdQmeanval','stdQphase')


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% PART 2: Fywp computation with ratio approach
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Construction of precipitation isotope time series according to all construction options
% and computation of Fywp, Fywpeq, Fywpstar
% (see table 1 of the paper) & Sine wave fitting

% For precip and peq, all results are computed with fixed phase (fixe to
% air temperature phase) and estimated phase; thus all corresponding
% results have two columns (1: fixed, 2: estimated). For pstar this is not
% the case (cannot fix the phase after weighing precip isotopes with peq amounts)

%% 2.1 compute air temp phase to use as forcing for precip isotopes
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

sinefitopts.StartPoint = [0 0 0]; weights=[]; % no weights
[xDataT, yDataT] = prepareCurveData(t, temp); % matlab function

[ampliTemp,phaseTemp,meanTemp,sinefitConfIntTemp,sinefitAdjR2Temp]=sinefit(xDataT,yDataT,weights,nTimeStepsPerYear,sinefitopts);
% look at result:
% tempsine= ampliTemp.*sin(2.*pi./nTimeStepsPerYear.*(t-phaseTemp))+meanTemp;
% plot(temp);hold on; plot(tempsine,'-r')

% define all possible time series construction options
[rain_sampOpts,rain_weighOpts,rain_dayOpts,...
    snow_sampOpts,snow_weighOpts,snow_dayOpts]=isotimeseries_options;

[optmat] = construct_isotimeseries(preciptimeserieschoice); 
% lists all possible ways to construct preciptiation time series, each row
% contains a 6 -digit number

optmat_PrecipIsoFitAdjR2 = zeros(size(optmat, 1)  ,1); % blank vector with the Adj R2 to fill

%% 2.2 compute sine fits to precip, peq, pstar and corresponding Fyw for all options
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for i=1:size(optmat, 1)
    if round(i/100)==i/100
        'construction precip iso series, case'
        i
    end
    choice=optmat(i, :);
    
    
    % Precipitation: read isotopes corresponding to option
    isotimeseries_optionNames= [rain_sampOpts(choice(1));rain_weighOpts(choice(2)); rain_dayOpts(choice(3)); snow_sampOpts(choice(4)); snow_weighOpts(choice(5)); snow_dayOpts(choice(6))];
    [iso_precip_dt, iso_precip, iso_precip_mm ] = precip_timeseries_t3 (choice, datenum(datemeteo),precip,limsElevationBands, swe, snowfall,iso_rain_dt0,iso_rain_dtc,iso_rain_elev,iso_rain,iso_rain_mm, iso_snow_dt,iso_snow_elev,iso_snow,iso_snow_bot_layer_cm,iso_snow_top_layer_cm);
    
    % prepare data for fitting
    ti = iso_precip_dt-initialtime; % bring to reference time
    [xDataP, ind ] = sort(ti);      % sort samples, call xData1
    yDataP = iso_precip(ind);
    wDataP = iso_precip_mm(ind);
    bad = isnan(xDataP+yDataP); % remove nans, but ignore nans ins weights at the moment, since xData1 will be used for Pstar
    xDataP(bad)=[]; yDataP(bad)=[]; wDataP(bad)=[];
    
    % prepare also for Pstar
    % find the time steps in Peq simulations corresponding to xData1
    timeRounded=floor(xDataP); wDataPeq=zeros(length(timeRounded),1);
    for tt=1:length(timeRounded)
        wDataPeq(tt,1)=peqtot(find(t==timeRounded(tt)));
    end % look at the weighing amounts: plot(t,peqtot); hold on; plot(timeRounded,wDataPeq,'o');  or: plot(xData1,yData1.*wDataPeq,'or')
    
    xDataPstar=xDataP; yDataPstar=yDataP; wDataPstar=wDataPeq;
    badPstar = isnan(xDataPstar+yDataPstar+wDataPstar); % remove nans
    xDataPstar(badPstar)=[]; yDataPstar(badPstar)=[];wDataPstar(badPstar)=[];
    
    %remove  nans in weights from dataP
    bad = isnan(wDataP); % remove nans
    xDataP(bad)=[]; yDataP(bad)=[]; wDataP(bad)=[];
    
    [xDataP, yDataP, wDataP]           = prepareCurveData(xDataP, yDataP, wDataP);
    [xDataPstar,yDataPstar,wDataPstar] = prepareCurveData(xDataPstar, yDataPstar, wDataPstar);
    
    % estimate sine fit with fixed phase, called ...1,
    % without fixed phase, all results are called ...2
    sinefitopts.StartPoint = [5 0];
    [ampliPrecipIso1,phasePrecipIso1,meanPrecipIso1,confIntPrecipIso1,adjR2PrecipIso1,dfePrecipIso1]=sinefit(xDataP,yDataP,wDataP,nTimeStepsPerYear,sinefitopts,phaseTemp);
    sinefitopts.StartPoint = [5 90 0];
    [ampliPrecipIso2,phasePrecipIso2,meanPrecipIso2,confIntPrecipIso2,adjR2PrecipIso2,dfePrecipIso2]=sinefit(xDataP,yDataP,wDataP,nTimeStepsPerYear,sinefitopts);
    [ampliPstarIso,phasePstarIso,meanPstarIso,confIntPstarIso,adjR2PstarIso,dfePstarIso]=sinefit(xDataPstar,yDataPstar,wDataPstar,nTimeStepsPerYear,sinefitopts);
    
    precipIsoSine1 = ampliPrecipIso1.*sin(2.*pi./nTimeStepsPerYear.*(t-phasePrecipIso1))+meanPrecipIso1;
    precipIsoSine2 = ampliPrecipIso2.*sin(2.*pi./nTimeStepsPerYear.*(t-phasePrecipIso2))+meanPrecipIso2;
    %  look at result
    % pstarIsoSine = ampliPstarIso.*sin(2.*pi./nTimeStepsPerYear.*(t-phasePstarIso))+meanPstarIso;
    % plot(xDataP,yDataP,'o');hold on; plot(t,precipIsoSine1,'-r'); plot(t,precipIsoSine2,'--r');plot(t,pstarIsoSine,'-c')
    
    % compute Peq isotopes
    snowIso1=zeros(length(temp),numbElevationBands); % with precipIsoSine1, fixed phase
    snowIso2=snowIso1;
    for j=1:numbElevationBands
        [snowIso1(:,j)] = peqisotopesim(rainfall(:,j), snowfall(:,j), precipIsoSine1, swe(:,j), snowmelt(:,j));
        [snowIso2(:,j)] = peqisotopesim(rainfall(:,j), snowfall(:,j), precipIsoSine2, swe(:,j), snowmelt(:,j));
    end
    
    peqIso(:,1)=(areaRatio(:)'*snowIso1')'; % equivalent precip isotopes
    peqIso(:,2)=(areaRatio(:)'*snowIso2')'; % equivalent precip isotopes
    
    % fit sine curve to peqIso
    ti = datemeteo-initialtime;
    sinefitopts.StartPoint = [5 90 0];
    [xDataPeq, ind ] = sort(ti); yDataPeq = peqIso(ind,:);wDataPeq=peqtot(ind);
    bad = isnan(xDataPeq+yDataPeq+wDataPeq); xDataPeq(bad)=[]; yDataPeq(bad,:)=[]; wDataPeq(bad)=[];
    [xDataPeq, yDataPeq(:,1), wDataPeq] = prepareCurveData(xDataPeq, yDataPeq(:,1), wDataPeq);
    [xDataPeq, yDataPeq(:,2), wDataPeq] = prepareCurveData(xDataPeq, yDataPeq(:,2), wDataPeq);
    
    [ampliPeqIso1,phasePeqIso1,meanPeqIso1,confIntPeqIso1,adjR2PeqIso1,dfePeqIso1]=sinefit(xDataPeq,yDataPeq(:,1),wDataPeq,nTimeStepsPerYear,sinefitopts);
    [ampliPeqIso2,phasePeqIso2,meanPeqIso2,confIntPeqIso2,adjR2PeqIso2,dfePeqIso2]=sinefit(xDataPeq,yDataPeq(:,2),wDataPeq,nTimeStepsPerYear,sinefitopts);
    
    % summarize results
    optmat_PrecipIsoFitAdjR2(i,1:2) = [adjR2PrecipIso1,adjR2PrecipIso2];
    
    ampliPrecipIsoAll(i,1:2)=[ampliPrecipIso1,ampliPrecipIso2];
    phasePrecipIsoAll(i,1:2)=[phasePrecipIso1,ampliPrecipIso2];
    meanPrecipIsoAll(i,1:2)=[meanPrecipIso1,ampliPrecipIso2];
    
    ampliPstarIsoAll(i,1)=[ampliPstarIso];
    phasePstarIsoAll(i,1)=[phasePstarIso];
    meanPstarIsoAll(i,1)=[meanPstarIso];
    
    ampliPeqIsoAll(i,1:2)=[ampliPeqIso1,ampliPeqIso2];
    meanPeqIsoAll(i,1:2)=[meanPeqIso1,meanPeqIso2];
    phasePeqIsoAll(i,1:2)=[phasePeqIso1,phasePeqIso2];
    
    
    % fitting uncertainty
    [stdPrecipAmpliAll(i,1) , stdPrecipMeanAll(i,1), stdPrecipPhaseAll(i,1)]=fituncertainty(confIntPrecipIso1,dfePrecipIso1,alphaFitFun);
    [stdPrecipAmpliAll(i,2) , stdPrecipMeanAll(i,2), stdPrecipPhaseAll(i,2)]=fituncertainty(confIntPrecipIso2,dfePrecipIso2,alphaFitFun);
    
    [stdPstarAmpliAll(i,1) , stdPstarMeanAll(i,1), stdPstarPhaseAll(i,1)]=fituncertainty(confIntPstarIso,dfePstarIso,alphaFitFun);
    
    [stdPeqAmpliAll(i,1) , stdPeqMeanAll(i,1), stdPeqPhaseAll(i,1)]=fituncertainty(confIntPeqIso1,dfePeqIso1,alphaFitFun);
    [stdPeqAmpliAll(i,2) , stdPeqMeanAll(i,2), stdPeqPhaseAll(i,2)]=fituncertainty(confIntPeqIso2,dfePeqIso2,alphaFitFun);
    
    %% compute Fyw with different options
    
    Fywp(i,1)=ampliPrecipIsoAll(i,1).^(-1)*ampliQIso; % with air temperature phase
    Fywp(i,2)=ampliPrecipIsoAll(i,2).^(-1)*ampliQIso; % with estimated phase
    Fywpeq(i,1)=ampliPeqIsoAll(i,1).^(-1)*ampliQIso;
    Fywpeq(i,2)=ampliPeqIsoAll(i,2).^(-1)*ampliQIso;
    Fywstar(i,1)=ampliPstarIsoAll(i,1).^(-1)*ampliQIso;
    
    
    [meanFywp(i,1) ,stdFywp(i,1)]=       ratioerror(ampliQIso,stdQamplitude,ampliPrecipIsoAll(i,1),stdPrecipAmpliAll(i,1),nMC);
    [meanFywp(i,2) ,stdFywp(i,2)]=       ratioerror(ampliQIso,stdQamplitude,ampliPrecipIsoAll(i,2),stdPrecipAmpliAll(i,2),nMC);
    [meanFywpeq(i,1),stdFywpeq(i,1)]=   ratioerror(ampliQIso,stdQamplitude,ampliPeqIsoAll(i,1),stdPeqAmpliAll(i,1),nMC);
    [meanFywpeq(i,2),stdFywpeq(i,2)]=   ratioerror(ampliQIso,stdQamplitude,ampliPeqIsoAll(i,2),stdPeqAmpliAll(i,2),nMC);
    [meanFywpstar(i,1),stdFywpstar(i,1)]= ratioerror(ampliQIso,stdQamplitude,ampliPstarIsoAll(i,1),stdPstarAmpliAll(i,1),nMC);
    
    
    
end %end loop over optmat

cd(generalresultspath); addpath(genpath(cd));

save(['all_options_','vdn','_02-Jul-2020'],'optmat','optmat_PrecipIsoFitAdjR2',...
    'ampliPrecipIsoAll','phasePrecipIsoAll','meanPrecipIsoAll','stdPrecipAmpliAll','stdPrecipMeanAll','stdPrecipPhaseAll',...
    'ampliPstarIsoAll','phasePstarIsoAll','meanPstarIsoAll','stdPstarAmpliAll','stdPstarMeanAll','stdPstarPhaseAll',...
    'ampliPeqIsoAll','phasePeqIsoAll','meanPeqIsoAll','stdPeqAmpliAll','stdPeqMeanAll','stdPeqPhaseAll',...
    'Fywp','Fywpeq','Fywstar',...
    'meanFywp','stdFywp','meanFywpeq','stdFywpeq','meanFywpstar','stdFywpstar')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% PART 3: Fywp computation with convolution approach
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

load(['all_options_','vdn','_02-Jul-2020'],'optmat','optmat_PrecipIsoFitAdjR2',...
    'ampliPrecipIsoAll','phasePrecipIsoAll','meanPrecipIsoAll','stdPrecipAmpliAll','stdPrecipMeanAll','stdPrecipPhaseAll',...
    'ampliPstarIsoAll','phasePstarIsoAll','meanPstarIsoAll','stdPstarAmpliAll','stdPstarMeanAll','stdPstarPhaseAll',...
    'ampliPeqIsoAll','phasePeqIsoAll','meanPeqIsoAll','stdPeqAmpliAll','stdPeqMeanAll','stdPeqPhaseAll',...
    'Fywp','Fywpeq','Fywstar',...
    'meanFywp','stdFywp','meanFywpeq','stdFywpeq','meanFywpstar','stdFywpstar')

allSamples=[]; % matrix to store all produced samples
countfiles=0;
for j=1:2 % compute for fixed phase and not fixed phase
    for i=1:length(optmat)
        i
        optmatchoice=i;
        load(['streamisotopes_',sitename,'.mat'],'iso_q_MeteoTime','iso_q_dt')% streamflow isotopes at meteo time steps
        
        for pp=1:nprecipIsoConv
            samplePamplitude(pp,j)=ampliPrecipIsoAll(i,j)+stdPrecipAmpliAll(i,j).*randn(1); % have two, one for fixed phase, one for est. phase
            samplePmean(pp,j)=meanPrecipIsoAll(i,j)+stdPrecipMeanAll(i,j).*randn(1);
            
            samplePphase(pp,j)=phasePrecipIsoAll(i,j)+stdPrecipPhaseAll(i,j).*randn(1); % only column 2 has variable phase
            
            precipIso = samplePamplitude(pp,j).*sin(2.*pi./nTimeStepsPerYear.*(t-samplePphase(pp,j)))+samplePmean(pp,j);
            
            
            % compute Peq isotopes
            snowIso=zeros(length(temp),numbElevationBands); % with precipIsoSine1, fixed phase
            for ee=1:numbElevationBands
                [snowIso(:,ee)] = peqisotopesim(rainfall(:,ee), snowfall(:,ee), precipIso, swe(:,ee), snowmelt(:,ee));
            end
            
            peqIso=(areaRatio(:)'*snowIso')'; % equivalent precip isotopes
            
            
            % prepare convolution input and output data to have the same time steps
            [convInput,convOutput,analysisVect]=datapreparation_convolution(datemeteo,iso_q_dt,iso_q_MeteoTime,peqIso(:,1),nTimeStepsPerYear,minQdataPerYear);
            
            % define the convolution function that is used to infer the
            % residence time distribution parameters, alpha and tau
            funConv = @(x)precipconv(x,convInput);
            x0=[.4,150]; % initial search value for alpha, tau
            
            % compute alpha and tau samples from posterior with Metropolis-Hastings algorithm
            samples=mh(convOutput,x0,@(x)(funConv(x)));
            % compute corresponding samples of Gamma_FywSamples
            for gg=1:length(samples)
                [Gamma_FywSamples(gg,1)]=youngwatfract(samples(gg,1),samples(gg,2),nTimeStepsPerYear); %comBS: V3
            end
            % retain only the number of samples that we would like to keep
            if nMCMCSamples==length(Gamma_FywSamples)
                retSamples=[1:length(Gamma_FywSamples)];
            elseif nMCMCSamples>length(Gamma_FywSamples)
                warning('you would like to retain more samples than produced by the MH algorithm, adapt the MH.m settings')
                retSamples=[1:nMCMCSamples];
            else % take a random selection of the output
                retSamples=round(random('Uniform',0.5,length(Gamma_FywSamples)-0.5,nMCMCSamples,1));% take a random subsample
                
            end
            allSamples=[allSamples;optmatchoice*ones(length(retSamples),1),pp*ones(length(retSamples),1),samples(retSamples,1),samples(retSamples,2),Gamma_FywSamples(retSamples)];
        end
        if round(i/100)==i/100
            countfiles=countfiles+1;
            if j==1
                filename=['randomSamp_allOptmatChoices_',sitename,'fixedphase_outputfile',num2str(countfiles)];
            else
                filename=['randomSamp_allOptmatChoices_',sitename,'estphase_outputfile',num2str(countfiles)];
            end
            save(filename,'allSamples','nMCMCSamples','nprecipIsoConv','optmat')
            allSamples=[];
        end
    end % end loop optmat
    
    countfiles=countfiles+1;
    if j==1
        filename=['randomSamp_allOptmatChoices_',sitename,'fixedphase_outputfile',num2str(countfiles)];
    else
        filename=['randomSamp_allOptmatChoices_',sitename,'estphase_outputfile',num2str(countfiles)];
    end
    save(filename,'allSamples','nMCMCSamples','nprecipIsoConv','optmat') % save last file
    
    % compose the samples at the end
    allSamplesComp=[];
    for i=1:countfiles
        filename=['randomSamp_allOptmatChoices_',sitename,'fixedphase_outputfile',num2str(i)];
        load(filename,'allSamples','nMCMCSamples','nprecipIsoConv','optmat')
        allSamplesComp=[allSamplesComp;allSamples];
    end
    
    locFywValues=size(allSamplesComp,2);
    locAlpha=3;
    locTau=4;
    
    % loop over all optmat choice and regroup samples for the same optmat,
    % not efficient but ok
    
    for i=1:max(allSamplesComp(:,1)) % this contains the optmat choice number
        if round(i/100)==i/100
            i
        end
        ind=find(allSamplesComp(:,1)==i);
        extract=allSamplesComp(ind,[locAlpha,locTau,locFywValues]);
        if isempty(extract) %cannot not happen with full looping over optmat
            MeanFywConv(i,j)=-9999;
            StdFywConv(i,j)=-9999;
            MeanAlpha(i,j)=-9999;
            StdAlpha(i,j)=-9999;
            MeanTau(i,j)=-9999;
            StdTau(i,j1)=-9999;
        else
            MeanFywConv(i,j)=mean(extract(:,end));
            StdFywConv(i,j)=std(extract(:,end));
            MeanAlpha(i,j)=mean(extract(:,1));
            StdAlpha(i,j)=std(extract(:,1));
            MeanTau(i,j)=mean(extract(:,2));
            StdTau(i,j)=std(extract(:,2));
        end
        
    end
end

if j==1
    filename=['ConvolutionResults_',sitename,'_fixedphase_',date];
else
    filename=['ConvolutionResults_',sitename,'_estphase_',date];
end

save(filename,'MeanFywConv','StdFywConv','optmat','MeanAlpha','StdAlpha','MeanTau','StdTau');


