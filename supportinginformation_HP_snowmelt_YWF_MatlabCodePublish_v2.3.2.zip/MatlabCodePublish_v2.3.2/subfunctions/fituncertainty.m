function [stdAmpli,stdMean,stdPhase]=fituncertainty(confintval,dfe,alphaFitFun)

%  Subfucntion of snowFyw.m; matlab code that accompanies the paper
%  "Seasonal snow cover decreases fraction of young
%  water in high Alpine catchments"
%  submitted to Hydrological Processes Written by
%  Natalie Ceperley, University of Bern, natalie.ceperley@giub.unibe.ch
%  25-Mar-2020, Matlab version: '9.5.0.1298439 (R2018b) Update 7'
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% computes the uncertainty bands from the Matlab fit function output, 
% for the sine curve fitting parameters
% Input: confidence intervals, degree of freedom, dfe 
% and the confidence level alphaFitFun

tinvValue = tinv((1+alphaFitFun)/2, dfe);
StdevPeqest = (confintval(2,:)-confintval(1,:)) ./ (2*tinvValue);
stdAmpli = StdevPeqest(1);
stdMean = StdevPeqest(2);
if size(confintval,2)==3
    stdPhase = StdevPeqest(3);
else
    stdPhase=0;
end