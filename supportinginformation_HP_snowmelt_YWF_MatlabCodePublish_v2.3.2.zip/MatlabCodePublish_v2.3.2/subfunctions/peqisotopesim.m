function [Cs] = peqisotopesim(rainfall, snowfall, precipIso, swe, snowmelt,timestep)


%  Subfucntion of snowFyw.m; matlab code that accompanies the paper
%  "Seasonal snow cover decreases fraction of young
%  water in high Alpine catchments"
%  submitted to Hydrological Processes Written by
%  Natalie Ceperley, University of Bern, natalie.ceperley@giub.unibe.ch
%  25-Mar-2020, Matlab version: '9.5.0.1298439 (R2018b) Update 7'
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Input
% rainfall: mm per time step, column vector
% snowfall: snowfall in mm per time step, column vectro
% precipIso: precipitation isotopes per time step in per mil
% swe: snowpack at each time step in mm water equivalent
% snowmelt: snowmelt in mm per time step
% timestep: time step length
%
% Output:
%
% Cs: snow snowmelt isotopes in per mil

if nargin<6
    timestep=1; % time step
end
n = length(rainfall);
P=rainfall+snowfall;
Peq=snowmelt+rainfall;

h=swe; % snowpack height in w.e.

Cp=precipIso;



Cs = zeros(n,1);% SnowPackIso ratio
for i=1:n-1 
    if (timestep*Peq(i) + h(i))>0
        Cs(i)=(timestep*Cp(i)*P(i)+h(i)*Cs(i-1))./(timestep*Peq(i) + h(i+1)); % should be
        %                 Cs(i)=(timestep*Cp(i)*P(i)+h(i-1)*Cs(i-1))./(timestep*P(i) + h(i-1)); % previous
        %                 Cs2(i)=(timestep*Cp(i)*P(i)+h(i)*Cs2(i-1))./(timestep*P(i) + h(i)); % equivalent
    else
        Cs(i)=Cp(i);
    end
end


if (timestep*P(n) + h(n))>0
    Cs(n)=(timestep*Cp(n)*P(n)+h(n)*Cs(n-1))./(timestep*P(n) + h(n));
else
    Cs(n) = Cp(n);
end