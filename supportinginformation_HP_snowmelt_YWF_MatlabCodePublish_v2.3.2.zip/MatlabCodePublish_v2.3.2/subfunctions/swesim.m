function [swe,melt,rainfall,snowfall]=swesim(precip,temp,swe0,degdayfact,tmelt,tcr1,tcr2)

%  Subfucntion of snowFyw.m; matlab code that accompanies the paper
%  "Seasonal snow cover decreases fraction of young
%  water in high Alpine catchments"
%  submitted to Hydrological Processes Written by
%  Natalie Ceperley, University of Bern, natalie.ceperley@giub.unibe.ch
%  25-Mar-2020, Matlab version: '9.5.0.1298439 (R2018b) Update 7'
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Input:

% precip: mm/day time series, each column for a spatial unit or a single
% column for all units
% temp: �C time series, each column for a spatial unit or a single column
%           if a single unit
% swe0: initial snow water equivalent (in mm), either a single value or one
%         value per spatial band
% degdayfact: degree-day factor ( mm/�C/day)
% tmelt: critical temp. for melt, default value is 0�C
% tcr1: critical temp. for precipitation falling exclusively as snow
% tcr2: crit. temp. for precipitation falling exclusively as rain;
%       (between tcr1 and tcr2, linear mixture of the two)

% Output
% swe: simulated snowpack in mm water equivalent, w.e.
% melt: simulated melt in mm/time step
% rainfall: simulated rainfall in mm/time step, same size as temp
% snowfall: simulated snowfall in mm/time step, same size as temp

% attention: if temp has a nan time step, than the timestep is assigned to rain


%% default parameter values
if nargin<5 % tmelt not given
    tmelt=0; tcr1=0; tcr2=0;
end
if nargin==5 % if only the melt temperature is given, we also use it to
    % separate snowfall from rainfall based on a simple threshold
    tcr1=tmelt; tcr2=tmelt; 
end

nSpatialunits=size(temp,2);
if length(swe0)~=1&&length(swe0)~=nSpatialunits
    error('wrong number of inputs for swe0, either a single value or one per spatial unit')
end
if size(temp,2)~=size(precip,2)&&size(precip,2)~=1
    error('precip should have a single column or the same size as temp')
end
    

% check if one precip series per spatial unit
if size(precip,2)<size(temp,2)
    if size(precip,2)~=1
        error('Precipitation has more than one column but less than columns than temperature')
    end
    precip=repmat(precip,1,size(temp,2)); % give the same series to all units
end

%%compute snowfall/rainfall
snowfall=zeros(size(precip));
snowTimeSteps=find(temp<tcr1);
for j=1:size(temp,2)
    transitionTimeSteps=find(and(temp(:,j)>tcr1,temp(:,j)<=tcr2)); 
    % attention: has to be temp>tcr1, this way, if tcr1=tcr2, transitionTimeSteps is empty
    % otherwise, later on we divide by zero
    if ~isempty(snowTimeSteps)
        snowfall(snowTimeSteps)=precip(snowTimeSteps);
    end
    
    if ~isempty(transitionTimeSteps)
        snowfall(transitionTimeSteps,j)=precip(transitionTimeSteps,j)+(precip(transitionTimeSteps,j)/(tcr2-tcr1)).*(tcr1-temp(transitionTimeSteps,j));
    end
    
end
rainfall=precip-snowfall; % attention: if temp is nan, than the timestep is assigned to rain

%% compute snowmelt
swe=zeros(length(temp+1),size(temp,2)); 
swe(1,:)=swe0;

melt=zeros(size(temp,2)); 
for j=1:size(temp,2) % if there are different spatial units (e.g. elevation bands), do for all
    for i=1:length(temp)     % note: for daily (simple) snow cover model
        sweprec=swe(i,j);     % forward stepping is ok, for more complex model
        snowfallday=snowfall(i,j);        % e.g with refreezing for hourly time step
        tempday=temp(i,j);              % consider using an implicit scheme
        
        if tempday>tmelt
            snowmeltday=degdayfact*(tempday-tmelt);
            if snowmeltday>sweprec+snowfallday
                snowmeltday=sweprec+snowfallday; % snowmeltday cannot exceed existing storage
            end
        else snowmeltday=0;
        end
        
        swe(i+1,j)=sweprec+snowfallday-snowmeltday;
        
        % No need to check whether storage swe(i+1) is <0 since snowmeltday cannot be
        % larger than existing storage, see above
        melt(i,j)=snowmeltday;
    end
end
        
swe(end,:)=[]; % forward stepping scheme, remove last time step; could prefere to remove initial condition but this is shifting the whole series

