function [iso_precip_dt, iso_precip, iso_precip_mm ] = precip_timeseries_t3 (choice, date,precip,limsElevationBands, swe, snowfall,iso_rain_dt0,iso_rain_dtc,iso_rain_elev,iso_rain,iso_rain_mm, iso_snow_dt,iso_snow_elev,iso_snow_permil,iso_snow_bot_layer_cm,iso_snow_top_layer_cm); 

%  Subfucntion of snowFyw.m; matlab code that accompanies the paper
%  "Seasonal snow cover decreases fraction of young
%  water in high Alpine catchments"
%  submitted to Hydrological Processes Written by
%  Natalie Ceperley, University of Bern, natalie.ceperley@giub.unibe.ch
%  25-Mar-2020, Matlab version: '9.5.0.1298439 (R2018b) Update 7'
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Input: 
% 1. choice
% this is the choice, according to table 1 in the paper of how to construct
% the time series of samples of precipiation and corresponding weights. 
% -> set to a six digit number to compute a given option, ranging from 111111
% to 425746 (see Table 1 of the paper or below) to see all possible options
% go to constructisotimeseries.m or type constructisotimeseries(-1);

% 2-3: date,precip,
% this is daily precipitation, that covers at least the entire time series
% of the isotope samples in terms of date. This date corresponds to precip.  
% Date is in matlab datenum file. This includes daily rain and snow in mm. 

% 4: limsElevationBands this is an output of tempInterpol, the limits of
% all elevation bands



% 5-6: swe, snowfall,
% This is part of the output from swesim. 
%     swe: simulated snowpack in mm water equivalent, w.e.
%     snowfall: simulated snowfall in mm/time step, same size as temp


% 7-11: iso_rain_dt0,iso_rain_dtc,iso_rain_elev, iso_rain,iso_rain_mm, 
% Description of samples of isotope ratios in rain. Any isotope (2H or 18O
% is possible as long as it is consistently used). 
% All from the raw file: rainisotopes.csv with 13 columns: 
%     year,month,day,hour,minute,year,month,day,hour,minute,m_asl,iso_rain,mm
%     - cols 1-5 are the date and time that collection started
%     - cols 6-10 are the date and time of collection
%     - col 11 is the elevation (m. Asl.) of the collection point
%     - col 12 is the isotope value (per mil)
%     - col 13 is the depth of the collection (mm - volume divided by bucket/funnel area)

% 12-16: iso_snow_dt,iso_snow_elev,iso_snow_permil,iso_snow_bot_layer_cm,iso_snow_top_layer_cm
% Description of samples of isotope ratios in snow. Any isotope (2H or 18O
% is possible as long as it is consistently used). 
% all from the raw file: snowisotopes.csv with 9 columns: 
%     Year,Month,Day,Hour,Minute,z_m_asl,iso_snow_dO18,bot_cm,top_cm
%     - cols 1-5 are the date and time of collection
%     - col 6 is the elevation of collection
%     - col 7 is the isotope value of snow
%     - cols 8 and 9 are the bottom and top of collected layer in cm from surface, surface snow should have a top value of 0
% 


% Output: iso_precip_dt, iso_precip, iso_precip_mm
% this is a new set of vectors of isotopes in precipitation (both snow and
% rain) constructed according to the choice of table 1.  
% iso_precip_dt is the date vector, in matlab datenum format
% iso_precip is the isotope value (of the same isotopes provide for the original samples)
% iso_precip_mm is the weight assigned in mm 

% Snow Averaging and Pack Determination
% regroup snow data into one value per elevation per day

% use snowfall swe per elevationbands, and date
% for each time stamp and elevation in snowcomposite, find the moment that the
% snowpack started
% the depth of the current snowpack
% the ammount of the last snowfall
% the date of the last snowfall
[DZ, ~, dzi] = unique([floor(iso_snow_dt),iso_snow_elev], 'rows');
iso_snow_day=DZ(:,1); % was snowcomposit and sampled snowfall col 1
% iso_snow_day_z=DZ(:,2); % was snowcomposite and sampled snowfall col 2


[D, ~, Dii] = unique(DZ(:,1));
[~, ~, dmetind] = intersect(D, date);
dind = dmetind(Dii);
zbin = discretize(DZ(:,2), limsElevationBands);

iso_snow_day_maxdepth=nan(length(DZ),1); 
iso_snow_day_permil=nan(length(DZ),1); 
iso_snow_day_surf_meddepth=nan(length(DZ),1); 
iso_snow_day_surf_permil=nan(length(DZ),1); 
iso_snow_day_weightedbydepth=nan(length(DZ),1); 
iso_snow_day_modpackdepth=nan(length(DZ),1); 
iso_snow_day_modsnowfall=nan(length(DZ),1); 
iso_snowfall_prev=nan(length(DZ),1); 
iso_snowfall_prev_dt=nan(length(DZ),1); 
iso_snowpack_dt0=nan(length(DZ),1); 
iso_snowfall_prevmax=nan(length(DZ),1); 
iso_snowfall_prevmax_dt=nan(length(DZ),1); 

iso_snowpack_prevmax=nan(length(DZ),1); 
iso_snowpack_prevmax_dt=nan(length(DZ),1); 
iso_snowfall_totcurpack=nan(length(DZ),1); 
iso_snowpack_dtavg=nan(length(DZ),1); 

for i=1:length(DZ)
    snowdepth = [iso_snow_bot_layer_cm(dzi==i), iso_snow_top_layer_cm(dzi==i)];% temporary
    isovalues = iso_snow_permil(dzi==i); % temporary
    
    iso_snow_day_maxdepth(i)=nanmax(nanmax(snowdepth)); % max snowdepth per day per elevation this is snowcomposite 3
    iso_snow_day_permil(i)=nanmean(isovalues); % average value per day per snowdepth, snow composite 4 when not enough layers measured
    
    surffind = or(snowdepth(:,2)==0, isnan(snowdepth(:,2))); % is the layer to surface
    iso_snow_day_surf_meddepth(i) =nanmedian(snowdepth(surffind,1)); % this is sampled snowfall, approximate snowdepth of new snow % sampled snowfall 3
    iso_snow_day_surf_permil(i) = nanmean(isovalues(surffind)); % this is the average value of fresh snow, sampledsnowfall 4
    
    if isnan(iso_snow_day_maxdepth(i))
        iso_snow_day_weightedbydepth(i) = iso_snow_day_permil(i);
    else
        % equivalend of snowcomposite 4
        iso_snow_day_weightedbydepth(i) = sum(isovalues.*(snowdepth(:,2)-snowdepth(:,1))./nansum(snowdepth(:,2)-snowdepth(:,1)));  % the average isotopes weighted by snowpack snowdepth
    end
    
    
    iso_snow_day_modpackdepth(i) = swe(dind(i), zbin(i));  % modelled snow pack snowdepth
    iso_snow_day_modsnowfall(i) = snowfall(dind(i), zbin(i)); % modelled snow fall on that day
    
    % identify previous snowfall
    prevind = find(snowfall(1:dind(i),zbin(i))>0, 1, 'last' );
    iso_snowfall_prev(i) = snowfall(prevind, zbin(i)); % snowdepth of previous snowfall +> iso_prev_mm
    iso_snowfall_prev_dt(i) = date(prevind); % date of previous snowfall +>
    
    
    % identify current snow pack
    startind = find(swe(1:dind(i),zbin(i))==0, 1, 'last' );
    dt_packdev = date(startind:dind(i),:);
    packdev_tot = swe(startind:dind(i),zbin(i));
    packdev_fall = snowfall(startind:dind(i),zbin(i));
    
    % start of snow pack date => later can get midpoint of snowpack to collection
    iso_snowpack_dt0 (i) = dt_packdev(1);
    
    % date of peak snowpack since start of snowpack accumulation
    [iso_snowpack_prevmax(i), spprevmax_ind] = max(packdev_tot);
    iso_snowpack_prevmax_dt(i) = dt_packdev(spprevmax_ind);
    
    % date of peak snowfall since start of snowpack accumulation
    [iso_snowfall_prevmax(i), sfprevmax_ind] = max(packdev_fall);
    iso_snowfall_prevmax_dt(i) = dt_packdev(sfprevmax_ind);
    % precipitation amount of whole winter period until collection
    iso_snowfall_totcurpack(i) = sum(packdev_fall ); %interfprecip
    
    % day weighted average by snowfall amount over whole accumulation
    iso_snowpack_dtavg (i) = sum(dt_packdev.*(packdev_fall./sum(packdev_fall)));
    
    
end
clear snowdepth isovalues surffind




%% calculate intermediary precipitation based on met time series

interprecip=zeros(length(iso_rain_dt0),1); 
peakprecip=nan(length(iso_rain_dt0),1); 
wday=nan(length(iso_rain_dt0),1); 


for i=1:length(iso_rain_dt0)
    ind = and(date>=iso_rain_dt0(i), date<=iso_rain_dtc(i));
    if sum(ind)==0
    else
        interprecip(i) = sum(precip(ind));
        [~, bi] = max(precip(ind)); ci = date(ind);
        peakprecip(i) = ci(bi);
        wday(i) = ci'*(precip(ind)/sum(precip(ind)));
    end
end


Snow1=iso_snow_permil; % data as is % for 1
Snow_w1 = iso_snow_bot_layer_cm; % could fill back from snow composite.
Snow_day1 = iso_snow_dt; % could fill back from snow composite and subsequent calculations
 
Snow2 = iso_snow_day_weightedbydepth; % one sample per elevation for Snow =2 ... later 3, 4
Snow_w2 = [iso_snow_day_maxdepth, iso_snow_day_surf_meddepth, iso_snowfall_prev, iso_snowfall_totcurpack];
Snow_day2= [iso_snow_day, iso_snowpack_dt0,mean([iso_snow_day, iso_snowpack_dt0],2),  iso_snowfall_prevmax_dt, iso_snowpack_prevmax_dt, iso_snowpack_dtavg];
 
Snow_w1(:,2:4) = Snow_w2(dzi,2:4);
Snow_day1(:,2:6) = Snow_day2(dzi,2:6);
 
% how can there be two more days in the composite snow than in the raw snow data?
 
 
Snow5 = iso_snow_day_surf_permil;  % snowfall per elevation for Snow = 5,  and evet. 6, 7,
% then average / select it based on the options for rain. (4)
 
 




%% Assemble the Choice

Rain_w=[iso_rain_mm, interprecip];
Rain_day=[iso_rain_dtc, iso_rain_dt0, mean([iso_rain_dtc, iso_rain_dt0],2), peakprecip, wday];

RAin_w=Rain_w(:,choice(2));
RAin_day=Rain_day(:,choice(3));
if choice(1)== 1
    RAIN=iso_rain; RAIN_W=RAin_w; RAIN_DAY=RAin_day;
elseif choice(1) == 2
    [RAIN_DAY, ~, rdind] = unique(floor(RAin_day));
        RAIN=nan(length(RAIN_DAY),1); RAIN_W=RAIN; 
    for i=1:length(RAIN_DAY)
        RAIN(i,:)=nanmean(iso_rain(rdind==i));
        RAIN_W(i,:)=nanmean(RAin_w(rdind==i));
    end
elseif choice(3) ==3
    [RAIN_DAY, ~, rdind] = unique(floor(RAin_day));
            RAIN=nan(length(RAIN_DAY),1); RAIN_W=RAIN; 
    for i=1:length(RAIN_DAY)
        ind=find(rdind==i);
        RAIN(i,:)=iso_rain(ind)'*RAin_w(ind)/sum(RAin_w(ind));
        RAIN_W(i,:)=nanmean(RAin_w(ind)); % the average volume
    end
else
    RAIN=iso_rain(iso_rain_elev==mode(iso_rain_elev)); % most frequently sampled elevation
    RAIN_W = RAin_w(iso_rain_elev==mode(iso_rain_elev));% most frequently sampled elevation
    RAIN_DAY = RAin_day(iso_rain_elev==mode(iso_rain_elev));% most frequently sampled elevation
end


if choice(4) ==1
    SNow = Snow1; SNow_w=Snow_w1; SNow_day = Snow_day1;
else
    if choice(4)>=5
        SNow = Snow5;SNow_w=Snow_w2; SNow_day = Snow_day2;
    else
        SNow = Snow2; SNow_w=Snow_w2; SNow_day = Snow_day2;
    end
end

% now pick the Snow_w and snow_d according to choice (5) and (6)

SNOw_w = SNow_w(:,choice(5));
SNOw_day = SNow_day(:,choice(6));

% choice(4)
clear SNOW SNOW_W
if or(choice(4) ==3, choice(4) ==6) % if 3, 6, - average by day
    [SNOW_DAY, ~, sdi] = unique(floor(SNOw_day));
            SNOW=nan(length(SNOW_DAY),1); SNOW_W=SNOW; 
    for i=1:length(SNOW_DAY)
        ind=find(sdi==i);
        SNOW(i,:)= nanmean(SNow(ind));
        SNOW_W(i,:)= nanmean(SNOw_w(ind));
    end
elseif or(choice(4) ==4, choice(4) ==7) % if 4, 7, - average by day / weight by snowfall snowdepth
    [SNOW_DAY, ~, sdi] = unique(floor(SNOw_day));
                SNOW=nan(length(SNOW_DAY),1); SNOW_W=SNOW; 
    for i=1:length(SNOW_DAY)
        ind=find(sdi==i);
        SNOW(i,:)= SNow(ind)'*SNOw_w(ind)/nansum(SNOw_w(ind));
        SNOW_W(i,:)= nanmax(SNOw_w(ind));
    end
else % if 1, 2, 5 = as is
    SNOW=SNow; SNOW_W=SNOw_w; SNOW_DAY=SNOw_day;
end


iso_precip = [RAIN;SNOW];
iso_precip_dt =[RAIN_DAY;SNOW_DAY];
iso_precip_mm = [RAIN_W;SNOW_W];
