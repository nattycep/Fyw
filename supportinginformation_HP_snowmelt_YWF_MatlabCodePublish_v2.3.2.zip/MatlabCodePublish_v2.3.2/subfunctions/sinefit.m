function [amplitude,phase,meanval,sinefitConfInt,sinefitAdjR2,degFreedom]=sinefit(xData,yData,weights,nTimeStepsPerYear,opts,fixedPhase)
%  Subfucntion of snowFyw.m; matlab code that accompanies the paper
%  "Seasonal snow cover decreases fraction of young
%  water in high Alpine catchments"
%  submitted to Hydrological Processes Written by
%  Natalie Ceperley, University of Bern, natalie.ceperley@giub.unibe.ch
%  25-Mar-2020, Matlab version: '9.5.0.1298439 (R2018b) Update 7'
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



if ~isempty(weights)
    opts.Weights=weights; %otherwise no weights
else
    opts.Weights=[];
end


if nargin<6
    fixedPhase=[];
    ft = fittype( ['A*sin(2*pi/',num2str(nTimeStepsPerYear),'*(t-phi))+k'], 'independent', 't', 'dependent', 'data' );
else
    ft = fittype( ['A*sin(2*pi/',num2str(nTimeStepsPerYear),'*(t-',num2str(fixedPhase),'))+k'], 'independent', 't', 'dependent', 'data' );
end

[sinfitOut,gof] = fit( xData, yData, ft, opts);

amplitude=sinfitOut.A;
meanval=sinfitOut.k;

if isempty(fixedPhase)
    phase = sinfitOut.phi; %
else
    phase=fixedPhase;
end
sinefitConfInt=confint(sinfitOut);

if amplitude<0
    phase = phase + nTimeStepsPerYear/2; % make sure the tempPhase is positive
    amplitude=abs(amplitude);
    sinefitConfInt(:,1)=sort(abs(sinefitConfInt(:,1)));
    if size(sinefitConfInt,2)==3 % if phase is estimated
        sinefitConfInt(:,3)=sinefitConfInt(:,3)+ nTimeStepsPerYear/2;
    end
else
end


if  phase<0
    phase=phase+nTimeStepsPerYear;
end
if phase>nTimeStepsPerYear
   phase=phase-nTimeStepsPerYear;
end

sinefitAdjR2 =gof.adjrsquare;
degFreedom=gof.dfe;


