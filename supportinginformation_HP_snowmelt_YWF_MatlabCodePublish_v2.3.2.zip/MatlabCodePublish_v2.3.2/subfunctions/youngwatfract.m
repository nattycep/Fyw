function [AsAp,phaseShift,ywaAsAp,FywOpt,ywaOpt,...
    FywKirchner,ywaKirchner,deltaSolutions]=youngwatfract(alpha,tau,nTimeStepsPerYear,ComputeWaterAge)
%  Subfucntion of snowFyw.m; matlab code that accompanies the paper
%  "Seasonal snow cover decreases fraction of young
%  water in high Alpine catchments"
%  submitted to Hydrological Processes Written by
%  Natalie Ceperley, University of Bern, natalie.ceperley@giub.unibe.ch
%  25-Mar-2020, Matlab version: '9.5.0.1298439 (R2018b) Update 7'
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% input: parameters of a Gamma distribution, tau=mean(gammapdf(alpha,beta)), alpha*beta=tau
%        nTimeStepsPerYear: e.g. 365 for daily time step
%        ComputeWaterAge: if set to 1, we compute optimal water age for no agregation
%        bias, this is time consuming;
% attention: tau has to be in days here


% we estimate via % eq 8 and 9 of Kirchner, HESS 2016 the ratio *AsAp* and 
% the *phaseShift* from the gamma parameters; we also compute  the young water
% age (ywa) corresponding to AsAp (*ywaAsAp*)
% this corresponds to the simple solution if we do not want to know
% which is the actual water age that does not give an agregation bias;

% in addition we compute the optimal water age  corresponding to no
% agregation bias, by optimisation (*ywaOpt*) and by applying Kirchners' empirical
% equation (*ywaKirchner*); we also compute the corresponding youngwater
% fractions (*FywOpt* and *FywKirchner*). For completeness, we also compute
% the difference of the objective function between the two solutions, which
% should be positive since the optimisation should give better results than
% the empirical formula


if nargin<3
    nTimeStepsPerYear=365;
end
if nargin<4
    ComputeWaterAge=0;
end

f=1; % number of cycles per year, see eq. 8, Kirchner 2016, HESS

tauNorm=tau/nTimeStepsPerYear;


%YWF according to Kirchner
AsAp=(1+(2*pi*f*tauNorm/alpha)^2)^(-alpha/2); % this is what Kirchner calls YWF or Fyw, eq. 8

phaseShift=(alpha*atan(2*pi*f*tauNorm/alpha))/(2*pi)*nTimeStepsPerYear; %eq.9


% now compute the age to which the above dampening corresponds to if the
% distribution was gamma:
ywaAsAp = gaminv(AsAp,alpha,tau/alpha); % young water age assuming that the young water fraction is AsAp


% in addition:

% find the young water age (i.e. the time-value to be fed into the
% gamma distribution), for which there is no agregation bias (Fig 9 of the
% Kirchner paper), i.e. find the age that gives the same value for the young water fraction
% estimated from the ratio AsAp (eq.8)  and from the gammacdf 

% this has to be done per alpha 
% Kirchner proposed an empirical formulat:
[dummy,ywaKirchner]=estywfThreshold(alpha,nTimeStepsPerYear); % young water threshold age, for which there is no agregation bias, see function below
FywKirchner= gamcdf(ywaKirchner,alpha,tau/alpha);

if ComputeWaterAge==1

% We can also find this age by optimisation:
% what we  try to find is the age that minimizes the distance between 
% AsAp and Fyw=gamcdf(age,alpha,tau) for all tau values;
% thus define a vector of normalized tau values
vTauNorm=[0.001:0.001:1]; 

% compute AsAp for this tau vector and Fyw for this tau vector and a
% selected age, and compute the distance between the
% two things;
% AsApAll=(1+(2*pi*f*vTauNorm/alpha)^2).^(-alpha/2); % eq. 8
% Fyw_x= gamcdf(age_x,alpha,vTauNorm/alpha);
% delta=sum((AsApAll-Fyw_x).^2);

% now put all in a single function to be minimized

fun = @(x)sum((gamcdf(x,alpha,vTauNorm/alpha)-(1+(2*pi*f*vTauNorm/alpha).^2).^(-alpha/2)).^2);
x0=0.0; % boundaries of normalized age
x1=0.5; 
ywaOpt = fminbnd(fun,x0,x1)*nTimeStepsPerYear; %young water age
FywOpt= gamcdf(ywaOpt,alpha,tau/alpha);



deltaKirchner=fun(ywaKirchner/nTimeStepsPerYear);
deltaywaOpt=fun(ywaOpt/nTimeStepsPerYear);
deltaSolutions=deltaKirchner-deltaywaOpt; 

if deltaSolutions<0
    warning('The optimisation gives worse result than the Kirchner empirical formula, see youngwatfractVx.m')
end

else
    FywOpt=nan; ywaOpt=nan; deltaSolutions=nan;
end

    
function [normAgeEst,ageEst]=estywfThreshold(alpha,nTimeStepsPerYear)

% applies the empirical function of Kirchner, 2016, eq. 14

% copied from the paper
%"From the fitted value of alpha and tau one can also use
% Eq. (14) to estimate the threshold age for young water
% fractions that should aggregate nearly linearly and then, finally,
% estimate the young water fraction as Fyw(gammapdf(x,alpha,tau)

normAgeEst=0.0949+0.1065*alpha-0.012*alpha^2;% = age/nTimeStepsPerYear

if nargin==2
    ageEst=normAgeEst*nTimeStepsPerYear;
else
    ageEst=-9999;
end

% Reference Kirchner, 2016, HESS
% 
% Hydrol. Earth Syst. Sci., 20, 279�297, 2016
% www.hydrol-earth-syst-sci.net/20/279/2016/
% doi:10.5194/hess-20-279-2016
% 

