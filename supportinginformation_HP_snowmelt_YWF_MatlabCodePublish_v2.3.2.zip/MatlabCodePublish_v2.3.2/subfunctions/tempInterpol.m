function [tempMat,areaRatioPerBand,limsElevationBands]=tempInterpol(temp,meteoStationElev,lapserate,demPixels,numbElevationBands)

%  Subfucntion of snowFyw.m; matlab code that accompanies the paper
%  "Seasonal snow cover decreases fraction of young
%  water in high Alpine catchments"
%  submitted to Hydrological Processes Written by
%  Natalie Ceperley, University of Bern, natalie.ceperley@giub.unibe.ch
%  25-Mar-2020, Matlab version: '9.5.0.1298439 (R2018b) Update 7'
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Input:
% temp: �C, air temperature, column vector
% meteoStationElev: m, asl., reference elevation for meteo time series
% demPixels: m asl., elevation of all DEM pixels contained in catchment, column vector
% numbElevationBands: number of elevation bands for interpolation
% lapserate: air temperature change with elevation, 
%            has to be negative for a decrease with elevation, in �C per 1000 m 
%
% Output:
% tempMat:  air temperature matrix with one column per elevation band
% areaRatioPerBand: ratio of total area contained in each elevation band
% limsElevationBands: limits of all elevation bands

if lapserate>0
    warning('Your air temp. lapse rate is positive')
end

% with the below formulation with have n+1 limits, which then allows
% computing n mean elevations

[cellsPerBand,limsElevationBands] = histcounts(demPixels,numbElevationBands);
meanLims=(limsElevationBands(2:end)+limsElevationBands(1:end-1))/2;

areaRatioPerBand = cellsPerBand./sum(cellsPerBand); % fraction in each band

% calculate a temperature matrix with each column for 1 elevation band

tempMat=repmat(temp,1,numbElevationBands)+lapserate/1000*(meanLims-meteoStationElev);