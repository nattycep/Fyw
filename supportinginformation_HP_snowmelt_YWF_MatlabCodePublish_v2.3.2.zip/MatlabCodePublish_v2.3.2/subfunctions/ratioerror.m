function [meanRatio,stdRatio]=ratioerror(ampliQIso,stdQampli,ampliPIso,stdPampli,nMC)
%  Subfucntion of snowFyw.m; matlab code that accompanies the paper
%  "Seasonal snow cover decreases fraction of young
%  water in high Alpine catchments"
%  submitted to Hydrological Processes Written by
%  Natalie Ceperley, University of Bern, natalie.ceperley@giub.unibe.ch
%  25-Mar-2020, Matlab version: '9.5.0.1298439 (R2018b) Update 7'
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% computes the mean and the standard deviation of the amplitude ratio
% given the standard deviations of the amplitudes, by random sampling
% 
% Input: amplitudes of streamflow and precipitation, ampliQIso, ampliPIso
%          and corresponding standard deviations, number of random samples
%          to draw
%
% Output: mean of ratio meanRatio and standard deviation stdRatio of the ratio

randomQIso = ampliQIso + stdQampli*randn(nMC, 1);

randomPIso = ampliPIso + stdPampli*randn(nMC, 1);
ratio=randomQIso./randomPIso;
meanRatio=mean(ratio);
stdRatio=std(ratio);
