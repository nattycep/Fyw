function [precip,temp,datemeteo,...
   iso_rain_dt0,iso_rain_dtc ,iso_rain_elev ,iso_rain ,iso_rain_mm,...
   iso_snow_dt,iso_snow_elev,iso_snow,iso_snow_bot_layer_cm,iso_snow_top_layer_cm,...
   iso_q_dt,iso_q,iso_q_m3s,iso_q_MeteoTime,demPixels]=importcasestudydata(sitename)

%  Subfucntion of snowFyw.m; matlab code that accompanies the paper
%  "Seasonal snow cover decreases fraction of young
%  water in high Alpine catchments"
%  submitted to Hydrological Processes Written by
%  Natalie Ceperley, University of Bern, natalie.ceperley@giub.unibe.ch
%  25-Mar-2020, Matlab version: '9.5.0.1298439 (R2018b) Update 7'
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% output: all column vector format
% precipitation
% air temperature, 
% datemeteo: corresponding time daily time steps in

% iso_rain_dt0: date start of collection [Y, MO, D, H, MIN],
% iso_rain_dtc: date end of collection [Y, MO, D, H, MIN]
% iso_rain_elev: sample elevation [m asl.]
% iso_rain: isotopes [ per mil]
% iso_rain_mm: volume [mm]

% iso_snow_dt: date start of collection [Y, MO, D, H, MIN],
% iso_snow_elev: elevation,
% iso_snow_permil: isotopes [ per mil]
% iso_snow_bot_layer_cm: depth from surface to bottom of layer (cm>0)
% iso_snow_top_layer_cm: depth from surface to top of layer (cm>=0)

% iso_q_dt: date of streamflow isotope samples [Y, MO, D, H, MIN, SEC],
% iso_q: streamflow isotopes [ per mil]
% iso_q_m3s: instantaneous streamflow at sample time in m3/s

% demPixels: elevation of all pixels contained in the catchment, m asl.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% change to mat file folder
refpath=cd;
if exist(['Data/matfiles/', sitename], 'dir')==0 % make subfolder
    mkdir(['Data/matfiles/', sitename])
    cd(['Data/matfiles/', sitename])
end


% define csv file names
filenamesIn={'meteo','rainisotopes','snowisotopes','streamisotopes','DEM'};
% define mat names

filenamesOut={'meteo','rainisotopes','snowisotopes','streamisotopes','elevation'};

% meteo data
filecount=1;
data=importdata([filenamesIn{filecount},'_',sitename,'.csv']);meteo=data.data;
datemeteo=datenum(meteo(:,1),meteo(:,2),meteo(:,3));
precip=meteo(:,end-1); temp=meteo(:,end);

if max(datemeteo(2:end)-datemeteo(1:end-1))>1
    error('The meteo data does not have continuous daily data')
end
    

save([filenamesOut{filecount},'_',sitename,'.mat'],'precip','temp','datemeteo');


% rain isotope data
filecount=filecount+1;
data=importdata([filenamesIn{filecount},'_',sitename,'.csv']);isodata=data.data;


iso_rain_dt0 = datenum(isodata(:,1),isodata(:,2),isodata(:,3),isodata(:,4),isodata(:,5),zeros(size(isodata,1),1));
iso_rain_dtc = datenum(isodata(:,6),isodata(:,7),isodata(:,8),isodata(:,9),isodata(:,10),zeros(size(isodata,1),1));
iso_rain_elev = isodata(:,11);
iso_rain = isodata(:,12);
iso_rain_mm = isodata(:,13);
save([filenamesOut{filecount},'_',sitename,'.mat'], 'iso_rain_dt0', 'iso_rain_dtc', 'iso_rain_elev', 'iso_rain', 'iso_rain_mm')



% snow isotope data
filecount=filecount+1;
data=importdata([filenamesIn{filecount},'_',sitename,'.csv']);isodata=data.data;
iso_snow_dt = datenum(isodata(:,1),isodata(:,2),isodata(:,3),isodata(:,4),isodata(:,5),zeros(size(isodata,1),1));
iso_snow_elev = isodata(:,6);
iso_snow= isodata(:,7);
iso_snow_bot_layer_cm = isodata(:,8);
iso_snow_top_layer_cm = isodata(:,9);
save([filenamesOut{filecount},'_',sitename,'.mat'],  'iso_snow_dt','iso_snow_elev','iso_snow','iso_snow_bot_layer_cm','iso_snow_top_layer_cm')


% streamflow isotope data
filecount=filecount+1;
data=importdata([filenamesIn{filecount},'_',sitename,'.csv']);isodata=data.data;
iso_q_dt = datenum(isodata(:,1),isodata(:,2),isodata(:,3),isodata(:,4),isodata(:,5),isodata(:,6));
iso_q = isodata(:,7);
iso_q_m3s = isodata(:,8);



 
% find observed streamflow data per meteo time step
iso_q_MeteoTime = nan(length(datemeteo), 1);
for i=1:length(datemeteo) % daily means of observation data
    [year,month,day]=datevec(datemeteo(i));
    
    ind=find(and(iso_q_dt>=datenum(year,month,day),iso_q_dt<datenum(year,month,day)+1));
    if ~isempty(ind)
        iso_q_MeteoTime(i,1)=mean(iso_q(ind));
    else
        iso_q_MeteoTime(i,1)=nan;
    end
end
clear year month day

save([filenamesOut{filecount},'_',sitename,'.mat'], 'iso_q_dt','iso_q','iso_q_m3s','iso_q_MeteoTime')

% dem data
filecount=filecount+1;
data=importdata([filenamesIn{filecount},'_',sitename,'.csv']);demdata=data.data;
demPixels=demdata(:,1); % change last number according to what column contains elevation
save([filenamesOut{filecount},'_',sitename,'.mat'],'demPixels')

% elevation per pixel:
% - clip a DEM to the catchment area and export the resulting DEM to a csv file with the elevation in
% m.a.s.l in a single column

cd(refpath)