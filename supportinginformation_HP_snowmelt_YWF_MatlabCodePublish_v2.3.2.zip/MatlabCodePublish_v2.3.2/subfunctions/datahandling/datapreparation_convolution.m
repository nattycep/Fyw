function [convInput,convOutput,analysisVect]=datapreparation_convolution(datemeteo,iso_q_dt,iso_q_MeteoTime,peqIso,nTimeStepsPerYear,minQdataPerYear)
%  Subfucntion of snowFyw.m; matlab code that accompanies the paper
%  "Seasonal snow cover decreases fraction of young
%  water in high Alpine catchments"
%  submitted to Hydrological Processes Written by
%  Natalie Ceperley, University of Bern, natalie.ceperley@giub.unibe.ch
%  25-Mar-2020, Matlab version: '9.5.0.1298439 (R2018b) Update 7'
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Input:
% meteo date: times steps in matlab date number
% iso_q_t: time steps of obs. streamflow in matlab date number
% iso_q_MeteoTime: obs. streamflow isotopes at meteo date time steps,
% calculated during data import
%
% Output:
% convInput: input for convolution, precipitation of equivalent preip
% isotopes
% convOutput: observed output (streamflow isotopes) at the same time steps as input, to optimize
%       the convolution

% The data for convolution is limited to consecutive years with more than a min number data points

if nargin<6
    minQdataPerYear=12;
end

nyears = ceil(length(datemeteo)./nTimeStepsPerYear);
lim= nyears*nTimeStepsPerYear;

yrmat = reshape([datemeteo(1:end);nan(lim-length(datemeteo),1)], nTimeStepsPerYear, nyears);

% identify in which year that data points are located
% set years with too few points to nan
for i=1:length(iso_q_dt)
    [~, col] = find(yrmat==floor(iso_q_dt(i)));
    C_rem(i,:) = col;
end
[N, edges] = histcounts(C_rem, 1:(nyears+1));

greaterthanX= double(N>minQdataPerYear);
greaterthanX(greaterthanX==0)=NaN;

nyearsconseq = nan(nyears,1);

for i=1:nyears
    nyearsconseq(i) = max(cumsum(greaterthanX(i:end)));
end

[stopYear, startYear]= max(nyearsconseq);

startDay=nTimeStepsPerYear.*(startYear-1)+1;

if stopYear == nyears-1 % include the last year - partial data
    stopDay = length(datemeteo);
else
    stopDay = nTimeStepsPerYear*stopYear;
end

clear year;
% end identification good years

dv1 = datevec(datemeteo(startDay));    
dv2 = datevec(datemeteo(stopDay));

span = dv1(1):dv2(1);

n = span (end) - span (1);

d_base = datevec(datemeteo(startDay)) ; % reference date

% adjust the mean of the observed streamflow data to avoid effects du to
% this offset
iso_q_MeteoTime=iso_q_MeteoTime-nanmean(iso_q_MeteoTime)+mean(peqIso);

analysisVect=startDay:stopDay;

convInput=peqIso(analysisVect);
convOutput=iso_q_MeteoTime(analysisVect);