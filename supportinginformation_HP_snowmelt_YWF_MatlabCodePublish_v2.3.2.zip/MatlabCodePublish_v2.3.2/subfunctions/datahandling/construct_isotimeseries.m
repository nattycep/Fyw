 function [optmat] = construct_isotimeseries(preciptimeserieschoice)
 
 %  Subfucntion of snowFyw.m; matlab code that accompanies the paper
%  "Seasonal snow cover decreases fraction of young
%  water in high Alpine catchments"
%  submitted to Hydrological Processes Written by
%  Natalie Ceperley, University of Bern, natalie.ceperley@giub.unibe.ch
%  25-Mar-2020, Matlab version: '9.5.0.1298439 (R2018b) Update 7'
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% input: preciptimeserieschoice: precipitation isotope time series construction option

% output: optmat is a matrix with one row for each selected option
%         the number of options to compute is the number of rows in optmat
 
% preciptimeserieschoice is either 
%
% 1) a 6 digit number with one value for each of the 6 construction
%    choicies (see below)
% 2) 0 or 000000 for all options 
% 3) -1 to interactively choose the construction option

% The options are: see also isotimeseries_options

% Digit 1, option for rain isotope data:
% 1) all rain isotopes
% 2) averaged by day
% 3) weighted by rainfall collection volume average by day
% 4) only most frequently sampled elevation
% 0) All of the above

% Digit2,  enter option for weighting rain isotope data:
% 1) mm in field
% 2) sum of all  intermediary rain
% 0) All of the above

% Digit 3,  enter option for date stamp for rain isotope data:
% 1) day of collection
% 2) day of start of collection
% 3) midpoint of collection period
% 4) day of intermediary peak precip
% 5) weighted average of day
% 0) All of the above

% Digit 4,  enter option for snow isotope data:
% 1) all snow samples without any averaging
% 2) 1 composite per day per elevation
% 3) snowpack averaged by day
% 4) snowpack average by day weighted by depth
% 5) 1 snowfall per day per elevation
% 6) snowfall averaged by day
% 7) snowfall averaged by day weighted by snowfall depth
% 0) All of the above

% Digit 5, enter option for weighting snow isotope data:
% 1) mm snow depth
% 2) depth top layer
% 3) depth of previous snowfall
% 4) precipitation amount of whole winter period until collection
% 0) All of the above?

% Digit 5 enter option for date stamp for snow isotope data:
% 1) collection day
% 2) start of snow pack date
% 3) midpoint of snowpack to collection
% 4) date of peak snowfall since start of snowpack accumulation
% 5) date of previous snowfall
% 6) weighted average over whole accumulation
% 0) All of the above

[rain,rain_w,rain_day,snow,snow_w,snow_day]=isotimeseries_options;



if preciptimeserieschoice >=0  % then will just parse the preciptimeserieschoice into a, b, c, d, e, f
    
    a = floor(preciptimeserieschoice/10^5);preciptimeserieschoice = preciptimeserieschoice - a*10^5; 
    b = floor(preciptimeserieschoice/10^4);preciptimeserieschoice = preciptimeserieschoice - b*10^4; 
    c = floor(preciptimeserieschoice/10^3);preciptimeserieschoice = preciptimeserieschoice - c*10^3; 
    d = floor(preciptimeserieschoice/10^2);preciptimeserieschoice = preciptimeserieschoice - d*10^2; 
    e = floor(preciptimeserieschoice/10);preciptimeserieschoice = preciptimeserieschoice - e*10; 
    f = preciptimeserieschoice;


elseif preciptimeserieschoice <0 % will proceed with the questions to construct isotope time series

clc
init = 'Enter option for rain isotope data:'; 
for i=1:length(rain)
    init = [init newline num2str(i) ') ' rain{i}]; 
end
prompt = [init newline '0) All of the above?']; 
a = input(prompt); 
clc

init = 'Enter option for weighting rain isotope data:'; 
for i=1:length(rain_w)
    init = [init newline num2str(i) ') ' rain_w{i}]; 
end
prompt = [init newline '0) All of the above?']; 
b = input(prompt); 
clc

init = 'Enter option for date stamp for rain isotope data:'; 
for i=1:length(rain_day)
    init = [init newline num2str(i) ') ' rain_day{i}]; 
end
prompt = [init newline '0) All of the above?']; 
c = input(prompt); 
clc

init = 'Enter option for snow isotope data:'; 
for i=1:length(snow)
    init = [init newline num2str(i) ') ' snow{i}]; 
end
prompt = [init newline '0) All of the above?']; 
d = input(prompt); 
clc

init = 'Enter option for weighting snow isotope data:'; 
for i=1:length(snow_w)
    init = [init newline num2str(i) ') ' snow_w{i}]; 
end
prompt = [init newline '0) All of the above?']; 
e = input(prompt); 
clc

init = 'Enter option for date stamp for snow isotope data:'; 
for i=1:length(snow_day)
    init = [init newline num2str(i) ') ' snow_day{i}]; 
end
prompt = [init newline '0) All of the above?']; 
f = input(prompt); 

else
    print('check input options')
end

optlength = nan(1,6); 
if a==0; optlength(1) = length(rain); Amat = (1:optlength(1))'; else; optlength(1) = 1; Amat = a; end
if b==0; optlength(2) = length(rain_w); Bmat = (1:optlength(2))';else; optlength(2) = 1; Bmat = b; end
if c==0; optlength(3) = length(rain_day); Cmat = (1:optlength(3))';else; optlength(3) = 1; Cmat = c; end
if d==0; optlength(4) = length(snow); Dmat = (1:optlength(4))';else; optlength(4) = 1; Dmat = d; end
if e==0; optlength(5) = length(snow_w); Emat = (1:optlength(5))';else; optlength(5) = 1; Emat = e; end
if f==0; optlength(6) = length(snow_day); Fmat = (1:optlength(6))';else; optlength(6) = 1; Fmat = f; end

% Nopt = prod(optlength); 

for i=1:5
    if i==1
        mat1 = Amat; 
        n1 = optlength(1); 
    else
        mat1 = mattemp; 
        n1 = size(mattemp, 1); 
    end
    if i==1; mat2 = Bmat; 
    elseif i==2; mat2 = Cmat; 
    elseif i==3; mat2 = Dmat; 
    elseif i==4; mat2 = Emat; 
    else;        mat2 = Fmat; 
    end
n2= length(mat2); 
        
mattemp = [repmat(mat1,n2, 1), reshape(repmat(mat2, 1, n1)', n1*n2,1)]; 
end



optmat= mattemp; 



