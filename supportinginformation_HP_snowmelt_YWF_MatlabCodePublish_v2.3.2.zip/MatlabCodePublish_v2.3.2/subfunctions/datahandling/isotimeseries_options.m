function [rain_sampOpts,rain_weighOpts,rain_dayOpts,...
    snow_sampOpts,snow_weighOpts,snow_dayOpts]=isotimeseries_options(varargin)
%  Subfucntion of snowFyw.m; matlab code that accompanies the paper
%  "Seasonal snow cover decreases fraction of young
%  water in high Alpine catchments"
%  submitted to Hydrological Processes Written by
%  Natalie Ceperley, University of Bern, natalie.ceperley@giub.unibe.ch
%  25-Mar-2020, Matlab version: '9.5.0.1298439 (R2018b) Update 7'
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% this function contains the list of construction options


rain_sampOpts = {'all rain isotopes', 'averaged by day', 'weighted by rainfall collection volume average by day', 'only most frequently sampled elevation'};
rain_weighOpts = {'mm in field', 'sum of all  intermediary rain'};
rain_dayOpts={'day of collection', 'day of start of collection', 'midpoint of collection period', 'day of intermediary peak precip', 'weighted average of day'};
snow_sampOpts = {'all snow samples without any averaging', '1 composite per day per elevation', 'snowpack averaged by day', ...
    'snowpack average by day weighted by depth', '1 snowfall per day per elevation', 'snowfall averaged by day', ...
    'snowfall averaged by day weighted by snowfall depth'};
snow_weighOpts={'mm snow depth', 'depth top layer', 'depth of previous snowfall', 'precipitation amount of whole winter period until collection'};
snow_dayOpts = {'collection day', 'start of snow pack date','midpoint of snowpack to collection', ...
    'date of peak snowfall since start of snowpack accumulation', 'date of previous snowfall', 'weighted average over whole accumulation' };
