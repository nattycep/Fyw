function Hf=FTgamma(freqs,tau,alpha)

%  Subfucntion of snowFyw.m; matlab code that accompanies the paper
%  "Seasonal snow cover decreases fraction of young
%  water in high Alpine catchments"
%  submitted to Hydrological Processes Written by
%  Natalie Ceperley, University of Bern, natalie.ceperley@giub.unibe.ch
%  25-Mar-2020, Matlab version: '9.5.0.1298439 (R2018b) Update 7'
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Fourier transform of a Gamma function using the Matlab Fourier transform
% which is integral(f(x)*exp(-2i pi))dx
% as opposed to the Fourier transform used in Walck, 2007
% which is integral(f(x)*exp(2i pi))dx
% and the origin of the equation in the Kirchner HESS 2016 a paper


% Input: 
% frequency (freqs)
% tau and alpha of the gamma distribution
% where tau=mean(gamma)=alpha*beta

% Output: fourier transform


% FT of Gamma function according to Kirchner paper
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Hf=(1-i*f*tau/alpha).^(-alpha);
% this comes from Walck 2007 who says
% Hf=a^b/gamma(b)*int(x^(b-1)*exp(-x*(a-it))dx
% ie. the gampdf=a^b/gamma(b)*x^(b-1)*exp(-ax)
% and the Fourier transform is int(exp(i*t)*f(x))dx

% in Matlab the gampdf=1/beta^alpha*1/gamma(alpha)*x^(alpha-1)*exp(-x/beta)
% and the Fourier transform is int(exp(-i*t)*f(x))dx

% we thus have that 
% bWalck=alphaMatlab
% aWalck=1/betaMatlab
% and we find the equation that is in Kirchner's paper
% Hf=(1-i*f*beta).^(-alpha);

beta=tau/alpha;
% with Matlab normalization of the Fourier transform
Hf=(1+sqrt(-1)*freqs(:)*beta).^(-alpha); % due to normalization, with have a plus here
% attention: with correct freqs (variable) rather than freq0
% as in some inital coding

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% can check that Hf is indeed the Fourier transform of a Gamma distribution
% by plotting 

%plot(real(ifft(Hf)))

% and check the integral if the temporal time step is 1
%int_invHf=sum(real(ifft(Hf))) % since the time step is one, i.e. delta t = 1