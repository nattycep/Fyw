function [out]=precipconv(x,inData,logOffset)

%  Subfucntion of snowFyw.m; matlab code that accompanies the paper
%  "Seasonal snow cover decreases fraction of young
%  water in high Alpine catchments"
%  submitted to Hydrological Processes Written by
%  Natalie Ceperley, University of Bern, natalie.ceperley@giub.unibe.ch
%  25-Mar-2020, Matlab version: '9.5.0.1298439 (R2018b) Update 7'
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% computes the convolution of an isotope signal with the Fourier transform
% of the Gamme distribution 
% Input: inData, contains one column with the convolution input; if a
%       second column is given, this column contains the observed output and the
%       function is run in an error computation mode for optimisation
% x: the Gamma function parameters
% logOffset: the offset to be added to the time series so that we have a
%       postivie value and can compute the log (the error function uses the log
%       of the time series)
% Output: out is either the output of the error function (if inData has two
%       columns) or it is the convolution outpout itself


inObs=inData(:,1);
if size(inData,2)>1
    outObs=inData(:,2);
    errorFun=1; % if observed output is given, the function is used in an error computation mode
    if nargin==2
        logOffset=30; % default value for the offset to be used in the error function
    end
else
    errorFun=0;
    if nargout>1
        warning('requested to ouput error function value but no observed output given')
    end
end

alpha=x(1);%Gamma shape parameter, if <=1: than exponential distribution rather than gamma
tau=x(2);

nSamp=length(inObs);

if round(nSamp/2)~=nSamp/2 % if not pair n, then we would obtain less frequencies than time steps
    % solution: double last value
    inObs=[inObs(:);inObs(end)]; 
    nSamp=length(inObs);
    corr=1;
else
    inObs=inObs(:);
    corr=0;
end

freqStep=2*pi/nSamp;% frequency step
nmaxhalf=floor(nSamp/2);% number of frequencies corresponding to maximum
% resolvable frequency called Nyquist frequency

freqsShifted=[-nmaxhalf:nmaxhalf-1]*freqStep; %  compute
% all frequencies, rather than only the positive ones and shift the
% fft output

finShifted=fftshift(fft(inObs));
% attention: fft is symmetric about nmaxhalf+1,i.e. everything is symmetric
% except the 0th frequency, which represents the mean;


% the fft is multiplied by the number of sample points
% the ifft is normalized
% (this is how Matlab handels the normalisation with the sample size);


Hfshifted=FTgamma(freqsShifted,tau,alpha);

foutShifted=finShifted.*Hfshifted(:);% convolution: multiplication in the Fourier domain


outEst=real(ifft(fftshift(foutShifted)));
if corr==1
    outEst(end)=[];
end

% the other solution would be (takes less memory), to compute
% i) Hf(freqs(1:nmaxhalf)),
% ii) then zero pad Hf to the size of fin,
% iii) compute ifft(fin.*Hfpadded,'symmetric')/2 % the 2 is the
% normalisation since only half the data is used
%


if errorFun==1 
  out=nansum((log(logOffset+outObs)-log(logOffset+ outEst)).^2);
  if imag(out)~=0
     error('the logoffset is too small, we compute the log of negative values')
  end
else
   out=outEst;
end
  