The parameter file contains

Meteo station elevation in m asl.
Air temperature lapse rate in �C/1000 m
Degree-day factor for snowmelt in mm/�C/day
Lower air temperature threshold for snowfall (below which all snow)
Upper air temperature threshold for snowfall (above which all rain)